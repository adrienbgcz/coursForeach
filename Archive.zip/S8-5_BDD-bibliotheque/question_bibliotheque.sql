-- 1 Lister les titres des livres

-- 2. Lister les livres avec leur rayon

-- 3. Lister les auteurs de la bibliothèque

-- 3b. Lister les auteurs qui ont écrit des livres de la bibliothèque

-- 4. Lister les livres d'un auteur

-- 5. Lister les titres et auteurs des livres

-- 6. Lister les titres et auteurs des livres disponibles uniquement

-- vérification des dates pour les rendre cohérentes

-- ajout d'un livre qui n'a pas encore été emprunté

-- 7. Rechercher un livre par mots clés

-- 8. Lister les adhérents

-- 9. Afficher le titre, auteurs et date d'emprunt du livre d'un adhérent

-- 10. Afficher les livres en cours d'emprunt

-- 11. lister les livres avec plus d'1 auteur

-- 12. lister les livres qui ont été emprunté en 2021 avec l'adhérent

-- 13. lister le nombre d'emprunt par adhérent

-- 14. lister le nombre d'emprunt par année, par adhérent
