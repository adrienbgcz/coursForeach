const participant = {
    pseudo: 'Dudule59',
    telephone: '0698765432',
    email: 'dudule59@yahoo.fr',
    nom: 'Durand',
    prenom: 'Gérard',
    dateNaissance: '12/10/1981',
    adresseRue: 'rue des assoifés',
    adresseNumero: '123',
    adresseCp: '59000',
    adresseVille: 'Lille',
    permisNumero: '123456789',
    permisDate: '24/08/2000',
    permisPoints: '12',
    elligibilite: true,
};

console.log(participant)