const libraries = [
  {
    id: 1,
    name: "Ma collection Fantastique",
    person_id: 1
  },
  {
    id: 2,
    name: "Ma collection Comédie",
    person_id: 2
  }
];
module.exports = libraries;
