const users = [
  {
    id: 1,
    name: "Aurore"
  },
  {
    id: 2,
    name: "Thibaut"
  }
];

module.exports = users;
