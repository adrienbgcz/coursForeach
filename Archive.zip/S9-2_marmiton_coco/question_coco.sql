-- 1. Afficher la liste des jeux avec le libellé audience

-- 2. Afficher la liste des jeux du 1. et ajouter les libellés des genres présents sur les jeux

-- 3. Afficher les pseudo des joueurs et leurs preferences de jeux (on affiche également les joueurs qui n'ont pas de preference)

-- 4. Afficher les genres de jeux et le nombre de jeux de chaque genre

-- 5. Afficher les jeux tout public et enfant (titre jeux libelle audience)

-- 5b. Afficher les jeux de genre action et horreur

-- 6. Afficher les suggestions de jeux suivant les genres préférés d'un joueur particulier

-- 6b. Afficher les suggestions de jeux suivant les types préférés d'un joueur et qui ne sont pas encore dans sa bibliotheque

-- INSERT INTO bibliotheque(date_achat, prix_achat, id_joueur, id_jeu) VALUES ('2021-01-05', 19, 4, 12)
-- 7. Affiche la bibliotheque d'un joueur.

-- 8. pour chaque joueur, on affiche le nombre de jeux de sa bibliotheque, le prix d'achat total de sa bibliotheque et le prix total actuel de sa bibliotheque

-- 9.C'est les soldes, on souhaite mettre les jeux action, aventure, simulation et jeunesse à - 15%.

-- 10. pour chaque joueur, on affiche le nombre de jeux de sa bibliotheque, le prix d'achat total de sa bibliotheque et le prix total actuel de sa bibliotheque, et la difference de prix

-- 11. Suite a des plaintes de troubles du comportement chez les jeunes, on ajoute un age minimum sur les public visés par les jeux

-- 12. On affiche l'age minimum de chaque jeu

-- 13. On affiche les joueurs ayant des jeux qui ne correspondent pas a leur age ainsi que le jeu correspondant.

-- 14 inserer les jeux 'fantasy zone', final Fight' et 'World of Final Fantasy Maxima'

-- 15. En tant que fan de la série 'Final Fantasy', je souhaite reuperer les jeux, trié par date de sortie et qui dans leur nom:
--   a. contiennent 'final fantasy'

--   b. commencent par 'final fantasy'

--   c. contiennent 'final' et 'fantasy'

--   d contiennent 'final' ou 'fantasy'

-- 16. rechercher les jeux present dans les bibliotheques qui ont été acheté a un prix supperieur au prix actuel. on affiche egalement le speudo du joueur a qui appartient le jeu

-- 17. on souhaite gerer une colonne "desactive" sur les joueurs, qui sera a false par defaut.

-- 18. On souhaite afficher uniquement les joueurs qui sont actif.

-- 19. Suite a une plainte RGPD, on souhaite supprimer les données des joueurs "desactivé".
-- a. Afficher les joueurs inactif

-- b. on affiche la bibliotheque d'un des joueurs inactif pour voir ces jeux
