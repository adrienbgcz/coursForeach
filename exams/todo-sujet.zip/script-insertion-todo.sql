INSERT INTO employe (nom, prenom, numero_salarie)
VALUES ('Doe', 'John', '0000');


INSERT INTO todo (nom, description, date_fin, id_employe)
VALUES ('Finir le sujet', 'examen de fin de formation pour ForEach Academy', '2021-07-30', 1);