const { NotFoundException } = require('../exception/NotFoundException')
const { etiquettes } = require('./etiquettes.data')

const todos = [
    {
        id: 1,
        nom: 'cirer les pompes',
        description: 'faire des compliments au boss',
        date_fin: '2021-07-17T00:00:00.000Z',
        termine: false,
        idEtiquettes: [1, 2],
    },
    {
        id: 2,
        nom: 'reu importante',
        description: 'preparer la reunion du 12',
        date_fin: '2021-07-11T00:00:00.000Z',
        termine: true,
        idEtiquettes: [2],
    }
]

let sequence = 3;

function getAll(termine, etiquettes) {
    let todosToReturn = [...todos]
    if(termine != undefined){
        todosToReturn = todosToReturn.filter(td => (td.termine == termine))
    }
    if(etiquettes && etiquettes.length > 0){
        todosToReturn = todosToReturn.filter(td => {
            if(!td.idEtiquettes || td.idEtiquettes.length == 0){
                return false;
            }
            return etiquettes.some(etq => {
                return td.idEtiquettes.includes(etq)
            })
        })
    }
    return todosToReturn.map(td => {
        const newTd = { ...td, ...{ etiquettes: getEtiquettes(td.idEtiquettes) } }
        delete newTd.idEtiquettes
        return newTd;
    })
}

function findById(id){
    const todo = [...todos].find((etq) => isTodo(etq, id))
    if(!todo) {
        throw new NotFoundException(`Todo with id ${id} not exist`)
    }
    const newTodo = { ...todo, ...{ etiquettes: getEtiquettes(todo.idEtiquettes) } }
    delete newTodo.idEtiquettes
    return newTodo;
}

function remove(id){
    const indexTodoToDelete = todos.findIndex((td) => isTodo(td, id));
    if(indexTodoToDelete < 0){
        throw new NotFoundException(`Etiquette with id ${id} not exist`)
    }
    todos.splice(indexTodoToDelete, 1)
}

function isTodo(todo, id){
    return todo.id == id
}

function save(todo, id, replace) {
    if(todo.etiquettes) {
        todo.idEtiquettes = getIdEtiquettes(todo.etiquettes)
        delete todo.etiquettes
    }
    if(id) {
        const indexTodoToUpdate = todos.findIndex((etq) => isTodo(etq, id));
        if(indexTodoToUpdate < 0){
            throw new NotFoundException(`Etiquette with id ${id} not exist`)
        } else {
            if(replace) {
                todos[indexTodoToUpdate] = { id, ...todo}
            }
            else {
                console.log(todos[indexTodoToUpdate])
                if(todo.idEtiquettes) {
                    // merge etiquette
                    todos[indexTodoToUpdate].idEtiquettes.forEach(idEtq => {
                        if(!todo.idEtiquettes.includes(idEtq)){
                            todo.idEtiquettes.push(idEtq)
                        }
                    })
                }

                todos[indexTodoToUpdate] = { ...todos[indexTodoToUpdate], ...todo}
            }

        }
    } else {
        todos.push({ id: sequence++, ...todo })
    }
}

function getEtiquettes(idEtiquettes){
    if(!idEtiquettes){
        return []
    }
    return etiquettes.filter(etq => idEtiquettes.includes(etq.id))
}

function getIdEtiquettes (etiquettes) {
    console.log(etiquettes)
    return etiquettes.map(etq => etq.id)
}

module.exports = {
    getAll,
    findById,
    save,
    remove
};