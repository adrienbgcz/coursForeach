##Projet API de gestion de la todo-list en mode mock

###LISTE DES COMMANDES DISPONIBLES 

* Pour installer les dependances ``npm ìnstall``

* Pour lancer le projet ``npm start``


###LISTE DES ROUTES

Pour les étiquettes

* GET /etiquettes
* GET /etiquettes/{id}
* POST /etiquettes
* PUT /etiquettes/{id}
* DELETE /etiquettes/{id}


Pour les todos

* GET /todos 
  * Paramètres possibles : 
    * termine -> true/false
    * etiquettes -> id de l'etiquette. plusieurs valeurs possibles avec un OU à l'execution
* GET /todos/{id}
* POST /todos
  * creation d'un nouveau todo
* PUT /todos/{id}
  * remplace un todo avec le todo du body
* PATCH /todos/{id}
  * modifie un todo avec le todo du body